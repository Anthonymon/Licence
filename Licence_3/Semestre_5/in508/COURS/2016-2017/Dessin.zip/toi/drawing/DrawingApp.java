package toi.drawing;

import java.util.ArrayList;
import java.util.List;

import toi.drawing.forms.Circle;
import toi.drawing.forms.Point;
import toi.drawing.forms.Rectangle;
import toi.drawing.forms.Shape;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Repr�sente l'application de dessin. Le programme est juste un petit exemple
 * d'appel de m�thodes des formes.
 * 
 * @version avr. 2009
 * @author St�phane Lopes
 */
public enum DrawingApp {
	ENVIRONNEMENT;

	/**
	 * Acc�s au log. 
	 */
	private static Log log = LogFactory.getLog("toi.drawing");

	/**
	 * M�thode principale du programme.
	 * 
	 * @param args les arguments de ligne de commande
	 */
	public void run(String[] args) {
		log.info("D�marrage du programme.");
		List<Shape> shapes = new ArrayList<Shape>();

		shapes.add(new Rectangle(new Point(0.0, 5.0), new Point(2.0, 2.0)));
		shapes.add(new Circle(new Point(1.0, 2.0), 3.0));
		shapes.add(new Rectangle(new Point(5.0, 5.0), new Point(7.0, 3.0)));
		shapes.add(new Circle(new Point(4.0, 5.0), 2.0));
		log.trace(shapes);

		for (Shape s : shapes) {
			s.translate(1.0, 2.0);
		}
		log.trace(shapes);
		log.info("Fin du programme.");
	}

	public static void main(String[] args) {
		ENVIRONNEMENT.run(args);
	}
}