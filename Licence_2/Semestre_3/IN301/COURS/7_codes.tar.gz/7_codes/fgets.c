#include <stdio.h>

char* ffgets(char* s, int n, FILE* iop){
  int c;
  char* cs;
  
  cs = s;
  while(--n > 0 && (c = getc(iop)) != EOF)
    if((*cs++ = c) == '\n')
      break;
  *cs = '\0';
  return (c == EOF && cs == s) ? NULL : s;
}



int main(void)
{
  char* str;
  FILE * fichier = fopen("essai.c", "r");
  if(fichier == NULL){
    printf("erreur\n");
  }
  ffgets(str, 256, fichier);
  printf("%s",str);
  fclose(fichier);
  return 0;
}
