#include <stdio.h>

void videBuffer(void){
    int c;
    do {
        c = getchar();
    } while (c != '\n' && c != EOF);
}
int main(){
  char c = 'a';
  int e = 7;
  char str[256];
  
  //supprimer ou ajouter le dernier / pour changer de fonction
  /**/
  scanf("%d", &e);
  scanf("%c", &c);
  //scanf("%d %c", &e, &c);
  printf("%d %c\n", e, c);
  /*/
    scanf("%s", str);
    printf("%s\n", str);
    //videBuffer();
    scanf("%c", &c);
    printf("%c", c);
    scanf("%c", &c);
    printf("%c", c);
  //*/
  return 0;
}

