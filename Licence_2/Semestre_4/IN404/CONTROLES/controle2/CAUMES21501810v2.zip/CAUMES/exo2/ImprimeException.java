
/**
 * Write a description of class ImprimeException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImprimeException extends Exception
{
    public ImprimeException(String message){
        super(message);
    }
}
